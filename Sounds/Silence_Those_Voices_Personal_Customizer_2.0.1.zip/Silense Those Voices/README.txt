
How to Use.
* Extract zip file
* Run "build.bat" and select the voiceover files you would like to disable. Put in the Number hit enter, repeat as desired
* As you enter the numbers the original list that displays again will now indicate a disabled sound
* Enter DISABLEALL to disable all the voices and build the pack.
* Adding 135 will finish and build the pak file
* You can put a "+" (plus sign) before a number to hear an audio sample in English of what you are disabling (like this: +2)
* Move newly created file "__ShutUp.pak" to /GAMEDATA/PCBANKS in your NMS installation folder
* ex: C:/Program Files (x86)/Steam/steamapps/common/No Man's Sky/GAMEDATA/PCBANKS
* You can rename the pak without issue, still recommended to use _ prefix to keep it loading at an appropriate time.

Note: ﻿The new Pack file will be created in the same directory that the Batch file was run from

UNINSTALL
Remove mod file from /GAMEDATA/PCBANKS to uninstall

UNPACK (OPTIONAL)
* After building, but with the mod .pak file still in the same directory,
   run "unpack.bat".
* This will allow you to see the content and double check it has files in it
* The pak can also be decompiled by AMUMSS mod tool


Remember enter DISABLEALL to disable all the voices.
